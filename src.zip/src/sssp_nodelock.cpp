/* -*- mode: c++ -*- */

#include <stdio.h>
#include <iostream>
#include <assert.h>
#include <limits.h>
#include <cstring>
#include <pthread.h>
#include <atomic>
#include "simplegraph.h"
#include "Timer.h"

const int INF = INT_MAX;
SimpleCSRGraphUII g;
long numofthread;
pthread_mutex_t mutexnodes;
pthread_mutex_t mutexnodee;
std::atomic<bool> changed;

struct init_data{
	//SimpleCSRGraphUII g;
	unsigned int src;
	long tid;

};
typedef struct round_data{
	long tid;
	//bool change;
} round_data;

void *sssp_init(void *init_arg) {

  // for(int i = 0; i < g.num_nodes; i++) {
  //   g.node_wt[i] = (i == src) ? 0 : INF;
  // }
  struct init_data *local;
  local = (struct init_data *)init_arg;
	//SimpleCSRGraphUII g = local->g;
	unsigned int src = local->src;
	long tid = local->tid;

	int block = g.num_nodes/numofthread;
	if (tid == numofthread-1)
		for (int i = block*tid;i<g.num_nodes;i++){
			g.node_wt[i] = (i == src) ? 0 : INF;
		}
	else{
		for (int i = block*tid;i<block*(tid+1);i++){
			g.node_wt[i] = (i == src) ? 0 : INF;
		}
	}
	//printf("Thread %ld done\n",tid);
	//printf("Thread %ld: %u\n",tid,src);
	//printf("Thread %ld: %ld\n",tid,total);


	//pthread_exit((void *) init_arg);
	return 0;
}


void *sssp_roundp(void * arg){
	//round_data *data=(round_data *)arg;
	int tid = (long)arg;
	int block = g.num_nodes/numofthread;
	if(tid == numofthread-1)
	{

		for(unsigned int node = block*tid; node < g.num_nodes; node++) {
			pthread_mutex_lock(&mutexnode);
    	if(g.node_wt[node] == INF) continue;
    	pthread_mutex_unlock(&mutexnode);

    	for(unsigned int e = g.row_start[node]; e < g.row_start[node + 1]; e++) {
				pthread_mutex_lock(&mutexnode);
      	unsigned int dest = g.edge_dst[e];
      	int distance = g.node_wt[node] + g.edge_wt[e];

      	int prev_distance = g.node_wt[dest];

      	if(prev_distance > distance) {
					g.node_wt[dest] = distance;
					//data->change = true;
					changed.exchange(true);
      	}
    	}
  	}
  	pthread_mutex_unlock(&mutexnode);
	}
	else{
	pthread_mutex_lock(&mutexnode);
		for(unsigned int node = block*tid; node < block*(tid+1); node++) {
    	if(g.node_wt[node] == INF) continue;

    	for(unsigned int e = g.row_start[node]; e < g.row_start[node + 1]; e++) {

      	unsigned int dest = g.edge_dst[e];
      	int distance = g.node_wt[node] + g.edge_wt[e];

      	int prev_distance = g.node_wt[dest];

      	if(prev_distance > distance) {
					g.node_wt[dest] = distance;
					//data->change = true;
					changed.exchange(true);
      	}
    	}
  	}
  	//printf("%ld\n",data->tid);
  	pthread_mutex_unlock(&mutexnode);
	}
	return 0;
}

bool sssp_round(/*SimpleCSRGraphUII g*/) {

	changed.exchange(false);
	pthread_t threads[numofthread];
	int rc;
	void *status;
  //round_data info[numofthread];
	pthread_attr_t attr;
	pthread_attr_init(&attr);
	pthread_mutex_init(&mutexnodee,NULL);
	pthread_mutex_init(&mutexnodes,NULL);
  pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_JOINABLE);
  for(int th = 0;th<numofthread;th++)
  {
  	//info[th].tid = th;
  	//info[th].change = false;
  	pthread_create(&threads[th],&attr,sssp_roundp,(void *)th);
  }
  pthread_attr_destroy(&attr);
	for(int t = 0;t<numofthread;t++)
	{
			pthread_join(threads[t],NULL);

	}


  // for(unsigned int node = 0; node < g.num_nodes; node++) {
  //   if(g.node_wt[node] == INF) continue;

  //   for(unsigned int e = g.row_start[node]; e < g.row_start[node + 1]; e++) {

  //     unsigned int dest = g.edge_dst[e];
  //     int distance = g.node_wt[node] + g.edge_wt[e];

  //     int prev_distance = g.node_wt[dest];

  //     if(prev_distance > distance) {
		// 		g.node_wt[dest] = distance;
		// 		changed = true;
  //     }
  //   }
  // }

  return changed.exchange(false);
}

void write_output( const char *out) {
  FILE *fp;

  fp = fopen(out, "w");
  if(!fp) {
    fprintf(stderr, "ERROR: Unable to open output file '%s'\n", out);
    exit(1);
  }

  for(int i = 0; i < g.num_nodes; i++) {
    int r;
    if(g.node_wt[i] == INF) {
      r = fprintf(fp, "%d INF\n", i);
    } else {
      r = fprintf(fp, "%d %d\n", i, g.node_wt[i]);
    }

    if(r < 0) {
      fprintf(stderr, "ERROR: Unable to write output\n");
      exit(1);
    }
  }
}

int main(int argc, char *argv[])
{
  if(argc != 4) {
    fprintf(stderr, "Usage: %s ggraph outputfile numberofthreads\n", argv[0]);
    exit(1);
  }

	char *pEnd;
  //SimpleCSRGraphUII g;
  numofthread = strtol(argv[3],&pEnd,10);
  pthread_t threads[numofthread];
  long th;
  int rc;
	void *status;

  if(!g.load_file(argv[1])) {
    fprintf(stderr, "ERROR: failed to load graph\n");
    exit(1);
  }

  printf("Loaded '%s', %u nodes, %u edges\n", argv[1], g.num_nodes, g.num_edges);

  ggc::Timer t("sssp");

  int src = 0, rounds = 0;
	struct init_data init_thread[numofthread];
	pthread_attr_t attr;
	pthread_attr_init(&attr);
  pthread_attr_setdetachstate(&attr, PTHREAD_CREATE_JOINABLE);

  t.start();

	for(th = 0; th < numofthread;th++)
	{
		//bool m = true;
		//init_thread[th].g = g;
		init_thread[th].src = src;
		init_thread[th].tid = th;
		//init_thread[th].total = numofthread;

		pthread_create(&threads[th],&attr,sssp_init,(void *) &init_thread[th]);
	}
	//printf("%lddone\n",init_thread[1].tid);
  //sssp_init(g, src);
	pthread_attr_destroy(&attr);
	for(th=0; th<numofthread; th++)
	{
       pthread_join(threads[th], &status);
       //printf("Main: completed join with thread %ld having a status of \n",th);
  }

	//pthread_exit(NULL);
	//printf("Start\n");



  for(rounds = 0; rounds < g.num_nodes - 1; rounds++) {
    if(!sssp_round()) {
      //no changes in graph, so exit early
      break;
    }
  }

  t.stop();

  printf("%d rounds\n", rounds); /* parallel versions may have a different number of rounds */
  printf("Total time: %llu ms\n", t.duration_ms());

  write_output( argv[2]);

  printf("Wrote output '%s'\n", argv[2]);
  return 0;
}
